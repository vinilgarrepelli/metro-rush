package com.elaninnovations.metrorush;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.view.*;
import java.io.*;

public final class MainActivity extends Activity {
  private WebView web;
  private static final String HOST="appassets.androidplatform.net";
  @Override public void onCreate(Bundle saved) {
    super.onCreate(saved);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    getWindow().setStatusBarColor(0xff101b27);
    getWindow().setNavigationBarColor(0xff101b27);
    web=new WebView(this);
    web.setBackgroundColor(0xff101b27);
    setContentView(web);
    web.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener(){ public WindowInsets onApplyWindowInsets(View v,WindowInsets insets){
      v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;}
    });
    WebSettings s=web.getSettings();
    s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
    s.setAllowFileAccess(false);s.setAllowContentAccess(false);
    s.setMediaPlaybackRequiresUserGesture(true);
    s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return !HOST.equals(r.getUrl().getHost());}
      @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){
        String path=r.getUrl().getPath();
        if(!HOST.equals(r.getUrl().getHost())||path==null||path.contains(".."))return error();
        if(path.equals("/"))path="/index.html";
        String mime=path.endsWith(".js")?"text/javascript":path.endsWith(".css")?"text/css":path.endsWith(".html")?"text/html":"application/octet-stream";
        try{return new WebResourceResponse(mime,"UTF-8",getAssets().open(path.substring(1)));}catch(IOException e){return error();}
      }
      private WebResourceResponse error(){return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",null,new ByteArrayInputStream(new byte[0]));}
    });
    web.loadUrl("https://"+HOST+"/index.html");
  }
  @Override protected void onPause(){web.evaluateJavascript("window.dispatchEvent(new Event('nativePause'))",null);web.onPause();super.onPause();}
  @Override protected void onResume(){super.onResume();if(web!=null)web.onResume();}
  @Override public void onBackPressed(){new android.app.AlertDialog.Builder(this).setTitle("Leave Metro Rush?").setMessage("Your personal best is saved.").setPositiveButton("Exit",new android.content.DialogInterface.OnClickListener(){ public void onClick(android.content.DialogInterface d,int w){finish();}}).setNegativeButton("Keep playing",null).show();web.evaluateJavascript("window.dispatchEvent(new Event('nativePause'))",null);}
  @Override protected void onDestroy(){if(web!=null){web.destroy();web=null;}super.onDestroy();}
}

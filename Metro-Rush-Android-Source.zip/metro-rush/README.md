# Metro Rush for Android

An original Subway Surfers–style 3D endless runner: three lanes, trains, jumping, sliding, coins, increasing speed and local high scores. The complete game runs offline inside an Android WebView; no internet permission, analytics, account, or network services are used.

## Install

Copy `Metro-Rush.apk` to an Android 8.0+ phone, open it, and allow installation from that file-opening app if Android asks. Requires OpenGL ES 3.0 and a current Android System WebView with WebGL 2 support. Swipe or use the on-screen arrows. The wrapper and APK have been compiled and signature-checked, but not tested on a physical phone or emulator.

This is a development-signed APK for direct installation, not a Play Store release. Fresh builds use a new development key; uninstall the earlier build before installing one with a different key (this clears scores). For release builds, keep a stable private signing key outside the repository and configure secure CI signing.

## Build locally

Install JDK 17, Python 3, Android SDK platform 35 and build-tools 35.0.0. Set `ANDROID_SDK_ROOT` to your SDK directory, then run:

```sh
bash build.sh
```

The APK is created at `build/Metro-Rush.apk`. The build uses official Android packaging/signing tools directly and does not need Gradle. As an alternative to javac, the script accepts `ECJ_JAR` pointing to Eclipse compiler 3.37.0.

## GitHub build

Push this folder to your repository. Under **Actions → Build Android APK**, select **Run workflow**. Download `Metro-Rush-Android` from the successful run's artifacts and unzip the APK. Pushes to main/master also build automatically. No signing keys are committed.

## Source

- `app/src/main/assets/`: all game code and bundled Three.js modules.
- `app/src/main/java/`: Android wrapper, local asset delivery, and pause lifecycle.
- `app/src/main/AndroidManifest.xml`: app identity and supported Android versions.
- `.github/workflows/android.yml`: reproducible APK build workflow.

Three.js is distributed under its included MIT license at `app/src/main/assets/vendor/THREE-LICENSE.txt`. Metro Rush uses original game geometry and branding; no Subway Surfers assets are included.

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
: "${SDK:?Set ANDROID_SDK_ROOT to an Android SDK with platform 35 and build-tools 35.0.0}"
BT="$SDK/build-tools/35.0.0"
ANDROID_JAR="$SDK/platforms/android-35/android.jar"
mkdir -p build/classes build/dex build/generated
"$BT/aapt2" compile --dir app/src/main/res -o build/resources.zip
"$BT/aapt2" link -o build/base.apk -I "$ANDROID_JAR" --manifest app/src/main/AndroidManifest.xml --java build/generated -A app/src/main/assets build/resources.zip
if command -v javac >/dev/null; then
  javac -source 8 -target 8 -bootclasspath "$ANDROID_JAR" -d build/classes app/src/main/java/com/elaninnovations/metrorush/MainActivity.java
else
  : "${ECJ_JAR:?Install JDK 17 or set ECJ_JAR to the Eclipse Java compiler jar}"
  java -jar "$ECJ_JAR" -source 8 -target 8 -bootclasspath "$ANDROID_JAR" -d build/classes app/src/main/java/com/elaninnovations/metrorush/MainActivity.java
fi
mapfile -t CLASSES < <(find build/classes -name '*.class')
"$BT/d8" --min-api 26 --lib "$ANDROID_JAR" --output build/dex "${CLASSES[@]}"
cp build/base.apk build/unsigned.apk
python3 - <<'PY'
from zipfile import ZipFile, ZIP_DEFLATED
from pathlib import Path
with ZipFile('build/unsigned.apk','a',ZIP_DEFLATED) as z:
 for p in Path('build/dex').glob('*.dex'):z.write(p,p.name)
PY
"$BT/zipalign" -f 4 build/unsigned.apk build/aligned.apk
if [ ! -f build/debug.keystore ]; then
  keytool -genkeypair -keystore build/debug.keystore -storepass android -keypass android -alias androiddebugkey -dname 'CN=Android Debug,O=Android,C=US' -keyalg RSA -keysize 2048 -validity 10000 -noprompt
fi
"$BT/apksigner" sign --ks build/debug.keystore --ks-pass pass:android --key-pass pass:android --out build/Metro-Rush.apk build/aligned.apk
"$BT/apksigner" verify --verbose build/Metro-Rush.apk
printf '\nAPK ready: build/Metro-Rush.apk\n'
